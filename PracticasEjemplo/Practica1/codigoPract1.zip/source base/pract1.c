
#include <p30f4011.h>
#include "leds.h"
#include "delay.h"
#include "keyb.h"

_FOSC(CSW_FSCM_OFF & EC_PLL16);
_FWDT(WDT_OFF);
_FBORPOR(MCLR_EN & PBOR_OFF & PWRT_OFF);
_FGS(CODE_PROT_OFF);

int main (void)
{
	char c;
	char lastc = 0;

	initLEDs();
	initKeyb();


	while (1)
	{
		c = getKey();
		c = c % 6;

		if (c != lastc)
		{
			offLED(lastc);
		}

		onLED(c);

		lastc = c;
	}

	return 0;
}
