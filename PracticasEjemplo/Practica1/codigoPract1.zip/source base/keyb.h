

// Inicializar teclado
void initKeyb();

// Determinar la tecla que se ha pulsado
unsigned char getKey();
