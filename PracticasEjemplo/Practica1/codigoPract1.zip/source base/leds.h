
/* ================================ */
/*	Libreria LEDs					*/
/* ================================ */

#define NUMLEDS	6

// Inicializar LEDs
void initLEDs();

// Encender LED
void onLED(unsigned char numLED);

// Apagar LED
void offLED(unsigned char numLED);
